@echo off
title Install APEX Blaze on an MPC
cd /d "%~dp0"
echo.
echo  APEX BLAZE installer
echo  ---------------------------------------------
echo  The MPC must be on the same Wi-Fi/network as this PC, with SSH (root) enabled.
echo  Find its IP on the MPC: Menu ^> Preferences ^> Network (or Wi-Fi).
echo  SAVE YOUR PROJECT FIRST: MPC restarts during the install.
echo.
set /p MPCIP= Type the MPC's IP address and press Enter: 
if "%MPCIP%"=="" exit /b 1
set KEYARG=
if exist "%USERPROFILE%\.ssh\apex_mpc" set KEYARG=-i "%USERPROFILE%\.ssh\apex_mpc"
echo.
echo Copying APEX Blaze to the MPC (if it asks for a password, type the MPC's root password)...
tar -cf - -C "%~dp0." "Gen1 - MPC Live, Live II, One, X, Key 61, Force" mpc-auto-install.sh | ssh -o ConnectTimeout=10 -o StrictHostKeyChecking=accept-new %KEYARG% root@%MPCIP% "rm -rf /tmp/apexblaze && mkdir -p /tmp/apexblaze && tar -xf - -C /tmp/apexblaze"
if errorlevel 1 (echo. & echo Could not reach the MPC at %MPCIP%. Check the IP, the network and that SSH is on. & pause & exit /b 1)
echo Installing...
ssh -o ConnectTimeout=10 %KEYARG% root@%MPCIP% "sh /tmp/apexblaze/mpc-auto-install.sh; rm -rf /tmp/apexblaze"
echo.
pause
