APEX BLAZE 0.9.5  -  rock / metal guitar instrument for MPC standalone
=====================================================================

Pages: GUITAR (360 showcase), TONE LAB, PEDALS, AMP, CAB, TONE
13 factory presets + 3 User slots (your own sounds, saved on the MPC).

WHICH MPCs
  Gen 1 (32-bit): MPC Live, Live II, One, X, Key 61, Akai Force
  Gen 2 (64-bit): MPC Live III, One (2025), Key 37, XL
  Both builds are in this folder. The installer picks the right one by itself.
  This is NOT for MPC software on a computer (Windows/Mac desktop MPC 3).

WHAT YOU NEED
  Akai's stock MPC software doesn't install outside plugins on its own.
  The MPC needs SSH (root) access turned on, like a modded MPC.
  The computer and the MPC must be on the same network.

INSTALL (about 2 minutes)
  1. Unzip this anywhere: any drive or folder works.
  2. On the MPC, SAVE YOUR PROJECT (MPC restarts during the install).
  3. Windows: double-click  "Install APEX Blaze (Windows).bat"
     Mac/Linux: double-click "Install APEX Blaze (Mac-Linux).command"
  4. Type the MPC's IP address (MPC: Menu > Preferences > Network).
  5. When MPC comes back: add APEX Blaze to a track from the plugin browser.

  It installs to the MPC's INTERNAL drive, so it works with no USB stick or SD card.
  Running it again upgrades and keeps your User presets.

BY HAND (advanced)
  Copy the Gen1 or Gen2 folder to the MPC and run its install.sh as root.
  See INSTALL.md inside that folder.

UNINSTALL
  On the MPC as root: sh "<Gen folder>/uninstall.sh"

Made by APEX.
