#!/bin/sh
# APEX Blaze: runs ON the MPC (as root). Picks the right build for this MPC and the right internal Synths folder,
# then runs that build's own installer. Your projects and other plugins are not touched; MPC.settings is backed up.
HERE=$(cd "$(dirname "$0")" && pwd)
case "$(uname -m)" in
  armv7*) PKG="$HERE/Gen1 - MPC Live, Live II, One, X, Key 61, Force"; GEN=1 ;;
  aarch64) PKG="$HERE/Gen2 - MPC Live III, One 2025, Key 37, XL"; GEN=2 ;;
  *) echo "STOPPED: this is not an MPC standalone ($(uname -m))."; exit 1 ;;
esac
if [ "$GEN" = 1 ]; then
  if [ -d "/sdcard/VST2 Plugins" ]; then T="/sdcard/VST2 Plugins"
  elif [ -d /sdcard ]; then T=/sdcard/Synths
  elif [ -d /media/az01-internal ]; then T=/media/az01-internal/Synths
  else echo "STOPPED: no internal drive found."; exit 1; fi
else
  if grep -q " /nvme " /proc/mounts; then T=/nvme/Synths
  elif grep -q " /storage " /proc/mounts; then T=/storage/Synths
  else echo "STOPPED: no writable internal drive found (/nvme or /storage)."; exit 1; fi
fi
[ -d "$PKG" ] || { echo "STOPPED: this MPC is Gen$GEN. This download is for the other generation: get APEX-Blaze-0.9.5-Gen$GEN.zip."; exit 1; }
mkdir -p "$T" || { echo "STOPPED: can't write to $T"; exit 1; }
echo "MPC Gen$GEN ($(uname -m)); installing APEX Blaze into: $T"
cd "$PKG" && sh ./install.sh -y -t "$T" && echo "APEX-BLAZE-INSTALLED: add APEX Blaze to a track from the plugin browser (Instrument plugins)."
