#!/bin/sh
# APEX Blaze installer for Mac or Linux: double-click (Mac) or run `sh "Install APEX Blaze (Mac-Linux).command"`.
cd "$(dirname "$0")"
echo "APEX BLAZE installer. The MPC must be on this network with SSH (root) enabled. Save your project first: MPC restarts."
printf "MPC IP address: "; read IP; [ -n "$IP" ] || exit 1
tar -cf - "Gen1 - MPC Live, Live II, One, X, Key 61, Force" mpc-auto-install.sh | \
  ssh -o ConnectTimeout=10 -o StrictHostKeyChecking=accept-new root@"$IP" "rm -rf /tmp/apexblaze && mkdir -p /tmp/apexblaze && tar -xf - -C /tmp/apexblaze" || { echo "Could not reach the MPC at $IP."; exit 1; }
ssh -o ConnectTimeout=10 root@"$IP" "sh /tmp/apexblaze/mpc-auto-install.sh; rm -rf /tmp/apexblaze"
